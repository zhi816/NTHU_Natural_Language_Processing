# Report

Your Kaggle username: zhi816

Your public leaderboard score: （提交 Kaggle 後填入）

Your private leaderboard score: （11/23 公布後填入）


1. Describe your method for retrieving Wikipedia documents (5%) and report Recall@N on development set (5%).

Answer:

我讀 sample code 時發現，它只把 train 有標註過的頁面當候選，dev / test 的正確頁面如果沒在 train 出現過，就一定找不到。所以我改成讀完整的 `wiki_pages.jsonl`（共 1,187,751 頁），並把文件檢索拆成「先找候選、再排順序」兩步（這一段 v1、v2、v3 三個版本都相同）：

* **(1) 標題比對（找候選）**：維基的頁名常常就是 claim 裡的主角，例如 claim 在講某部電影，頁名通常就是那部電影的名字。我先把所有頁名正規化（去掉結尾的消歧義括號、統一「·」這類間隔號、去掉空白、英文轉小寫），做成「標題 → 頁面」的 dict，再把 claim 中所有長度 2～30 的子字串拿去查。查到的就是候選頁，長的標題比較具體所以排前面，每題最多留 30 頁。這一步只是 Python 的 dict 查詢，不用 GPU、也不用斷詞。dev 平均每題命中 17.5 頁，完全沒有命中任何標題的有 0 題（0.00%）。
* **(2) 向量排序**：候選頁用 `BAAI/bge-m3`（568M 參數）把「頁名：開頭 200 字」編成向量，claim 也編成向量，兩邊都做 L2 normalization，所以內積就是 cosine similarity。bge-m3 是專門為檢索訓練過的模型，訓練時用的是 [CLS] 位置的向量，所以我照它的設計取 [CLS]，而不是 sample code 的 mean pooling。為了照顧「claim 裡沒有直接寫出頁名」的題目，我另外在候選池（train 標註頁 3,188 頁 + 所有 claim 的標題命中頁，合計 41,081 頁）裡用向量再補 30 頁。
* **(3) 混合分數**：最終分數 = cosine + bonus × [這頁是否被標題命中]。bonus 我在 dev 上從 0.0, 0.05, 0.1, 0.15, 0.2, 0.3, 0.5, 1.0 裡挑 Recall@5 最高的，結果是 **0.05**，取前 5 頁進入下一階段。

**Dev 結果**：dev 共 3000 筆，Recall 只計算 SUPPORTS / REFUTES 的 2000 筆；某一組標準證據需要的頁面「全部」都在前 N 頁裡才算命中。

**Document Retrieval Recall@5 = 88.85%（1777 / 2000）**

| 方法 | R@1 | R@3 | R@5 | R@10 |
| :---: | :---: | :---: | :---: | :---: |
| 只用標題比對（長標題優先） | 42.85% | 66.70% | 76.15% | 83.00% |
| 只用 bge-m3 向量（bonus = 0） | 74.80% | 85.00% | 87.50% | 89.60% |
| 混合（bonus = 0.05） | 77.05% | 86.40% | 88.85% | 90.60% |

只用標題比對的 Recall@5 是 76.15%，只用向量是 87.50%，兩種合起來是 88.85%，比單用較好的那一種提升了 1.35 個百分點。另外，「標題命中 + 向量補充」的候選頁涵蓋率是 91.80%，這是排序再怎麼改都超不過的上限。

2. Describe your method for retrieving evidence (5%) and report Recall@N on development set  (5%).

Answer:

證據只能從第 1 階段取回的 5 頁裡挑。sample code 只把 train 標註過的句子當候選，我改成把這幾頁的**每一句**都當候選（保留維基原始的句號，不重新編號），全部共編碼了 134,939 句。每一句前面我都加上頁名（「頁名：句子」），因為很多句子是用「他」「該片」來代稱主角，不加頁名的話模型不知道這句在講誰。（這一段 v2、v3 相同。）

* **(1) 向量初篩**：用同一個 bge-m3 算 claim 和每一句的 cosine similarity，每題先留前 30 句。v1 只留 20 句，但我發現 reranker 再厲害也只能從初篩留下的句子裡挑，所以 v2 放寬到 30 句，提高上限。
* **(2) Cross-encoder 重排**：再用 `BAAI/bge-reranker-v2-m3`（568M 參數）把「claim + 句子」一起丟進模型打分數。向量檢索是 bi-encoder，claim 和句子各自算向量再比，速度快但兩邊沒有真正一起讀；cross-encoder 讓 claim 和句子的每個字互相做 attention，比較能分辨同一頁裡內容很接近的句子。
* **(3) 用 CFEVER train 微調 reranker（v2 新增）**：現成的 reranker 只學過一般的「這句和問題相不相關」，但 CFEVER 要的是「能用來判斷真假的那一句」，而且標註者挑句子有自己的習慣。所以我用 train 的 8,000 題 SUPPORTS / REFUTES 微調它：每題組成 1 個正例（標準證據句）+ 7 個 hard negative（bge-m3 初篩排很前面、但不是標準證據的句子），reranker 對 8 句各打一個分數，再把 8 個分數當成「8 選 1」做 cross entropy，目標是讓標準證據的分數比其他 7 句都高（listwise loss，參考 FlagEmbedding 訓練 bge-reranker 的方式）。為了讓 T4 放得下，我凍結了詞向量層（約 2.5 億參數），只訓練後面的 transformer 層；learning rate 2e-05、1 個 epoch、fp16 混合精度，大約花 14 分鐘。dev 完全沒有拿來訓練，微調完會和現成的模型在 dev 上比較，比較好才採用，最後用的是**微調後的** reranker。
* **(4) 固定給滿 5 句**：FEVER score 只看前 5 句，多給不會扣分，所以每題都輸出 5 句，盡量提高命中機會。

**Dev 結果**：同樣只算 2000 筆可驗證的題目，頁名和句號都要對，而且要完整涵蓋某一組標準證據才算命中。

**Evidence Retrieval Recall@5 = 85.50%（1710 / 2000）**

| 方法 | Evidence Recall@5 |
| :---: | :---: |
| bge-m3 向量取前 5 句 | 81.40% |
| bge-m3 向量前 20 句（v1 reranker 能到的上限） | 88.30% |
| bge-m3 向量前 30 句（v2 reranker 能到的上限） | 88.80% |
| ＋ 現成 bge-reranker 從 30 句重排取前 5 | 82.45% |
| ＋ 微調後 bge-reranker 從 30 句重排取前 5 | 85.50% |

只用向量挑 5 句的 Recall 是 81.40%；現成的 reranker 從 30 句重排後是 82.45%；用 train 微調 reranker 之後是 85.50%，比現成的提升了 3.05 個百分點，所以最後採用微調後的 reranker。向量前 30 句的 Recall 是 88.80%（前 20 句是 88.30%），這是 reranker 再厲害也超不過的上限，這也是我把初篩從 v1 的 20 句放寬到 30 句的原因。如果只看「文件已經找對」的題目，證據 Recall@5 是 96.23%：只要頁面找對，大部分題目都能把證據句找齊，證據 Recall 的損失主要來自第 1 階段沒有找到正確頁面。

3. Describe your classification method (5%) and report Accuracy on development set  (5%).

Answer:

v2 的三階段漏斗顯示，dev 裡「證據已經找齊、標籤卻判錯」的 SUPPORTS / REFUTES 有 417 題，比文件檢索（223 題）和證據檢索（60 題）掉的加起來還多，所以 v3 前兩個階段完全沿用 v2，只改分類。v2 只用一個 `hfl/chinese-roberta-wwm-ext-large`；v3 用同一份訓練資料訓練 3 個不同的模型，再把它們的機率平均（ensemble）。每個模型都是在預訓練模型上接一個三分類層（SUPPORTS / REFUTES / NOT ENOUGH INFO）：

| 模型 | 參數量 | learning rate | 凍結詞向量 | 採用的 epoch | dev Accuracy | dev FEVER（不調整） | dev FEVER（調 bias / 門檻） |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| chinese-roberta-wwm-ext-large | 326M | 1e-05 | 否 | 1 | 72.30% | 67.77% | 68.07% |
| chinese-macbert-large | 326M | 1e-05 | 否 | 1 | 72.90% | 68.47% | 69.00% |
| xlm-roberta-large | 560M | 8e-06 | 是 | 1 | 72.27% | 67.57% | 67.87% |

選這三個是因為它們「錯的地方不一樣」，平均起來才有幫助：

* `hfl/chinese-roberta-wwm-ext-large`：v2 用的模型，24 層、hidden size 1024，用中文語料做全詞遮罩（whole word masking）預訓練。
* `hfl/chinese-macbert-large`：大小和詞表都一樣，但預訓練時要猜的字不是換成 [MASK]，而是換成意思相近的詞（MLM as correction），預訓練和 fine-tune 看到的文字比較一致。
* `FacebookAI/xlm-roberta-large`：100 種語言一起預訓練，用 SentencePiece 斷詞，繁體字原生支援。它的詞表有 25 萬個，詞向量就佔了快一半參數，所以我凍結詞向量層（和 v2 微調 reranker 時一樣），省下梯度和 Adam 狀態的記憶體；它的學習率也調得比較小，因為 XLM-R large 用太大的學習率比較容易學不起來。

三個都是只做過語言模型預訓練的模型，沒有用其他標註資料集微調過，符合「只用 CFEVER」的規定。

每個模型的輸入和訓練資料都和 v2 相同：輸入是句對 `claim` + `【頁名】證據句1 【頁名】證據句2 …`，上限 512 token、每句證據最多 120 字、太長時只截斷證據不截斷 claim。SUPPORTS / REFUTES 的訓練資料如果標準證據不在檢索結果裡，就補進一組並放在最前面（2,749 筆有補）；NOT ENOUGH INFO 則用 reranker 從向量前 10 句挑 5 句，讓它和 test 時一樣「看起來很相關、但其實資訊不夠」。我也檢查過這個格式和 test 是否一致：dev 上證據有找齊的題目中，有 87.49% 的標準證據被 reranker 排在第 1 句，和訓練時「標準證據放最前面」吻合。

訓練用了 24,012 筆 train。設定是 AdamW、每批 8 筆並用 gradient accumulation 累積 2 批才更新一次（等效 batch size 16）、2 個 epoch、前 10% 的更新步數做 warmup 之後線性下降、gradient clipping 1.0、fp16 混合精度。每個 epoch 結束都在 dev 上看一次，各自採用 dev FEVER score 最高的 epoch：

`hfl/chinese-roberta-wwm-ext-large`：

| epoch | train loss | dev Accuracy | dev FEVER score |
| :---: | :---: | :---: | :---: |
| 1 | 0.7453 | 72.30% | 67.77% |
| 2 | 0.3900 | 70.83% | 66.87% |

`hfl/chinese-macbert-large`：

| epoch | train loss | dev Accuracy | dev FEVER score |
| :---: | :---: | :---: | :---: |
| 1 | 0.6985 | 72.90% | 68.47% |
| 2 | 0.3678 | 71.07% | 67.17% |

`FacebookAI/xlm-roberta-large`：

| epoch | train loss | dev Accuracy | dev FEVER score |
| :---: | :---: | :---: | :---: |
| 1 | 0.8182 | 72.27% | 67.57% |
| 2 | 0.5022 | 70.77% | 66.73% |

**Ensemble**：每個模型輸出的 logits 先做 softmax 變成三類機率，取平均後再取 log 當作新的分數（對單一模型來說，log softmax 和原本的 logits 只差一個常數，取 argmax 的結果不變）。我把所有模型組合（單一模型、兩兩一組、三個一起）都在 dev 上比過，每個組合各自挑最好的 NEI bias 和 reranker 門檻（第 4 題說明）：

| 模型組合 | Accuracy（不調整） | FEVER（不調整） | 最好的 NEI bias | reranker 門檻 | FEVER（調整後） |
| :---: | :---: | :---: | :---: | :---: | :---: |
| chinese-roberta-wwm-ext-large | 72.30% | 67.77% | -0.5 | 最低 12.5% | 68.07% |
| chinese-macbert-large | 72.90% | 68.47% | 0.0 | 最低 5% | 69.00% |
| xlm-roberta-large | 72.27% | 67.57% | 0.0 | 最低 10% | 67.87% |
| chinese-roberta-wwm-ext-large + chinese-macbert-large | 73.77% | 69.27% | 0.0 | 最低 5% | 69.50% |
| chinese-roberta-wwm-ext-large + xlm-roberta-large | 73.07% | 68.50% | 0.0 | 最低 5% | 68.73% |
| chinese-macbert-large + xlm-roberta-large | 73.97% | 69.30% | 0.0 | 最低 5% | 69.57% |
| chinese-roberta-wwm-ext-large + chinese-macbert-large + xlm-roberta-large | 74.53% | 69.80% | 0.0 | 最低 5% | 70.03% |

單一模型裡最好的是 chinese-macbert-large（調整後 dev FEVER score 69.00%），選用的組合是 70.03%，提升了 1.03 個百分點。最後用的是 **chinese-roberta-wwm-ext-large + chinese-macbert-large + xlm-roberta-large**，NEI bias = 0.0、門檻 = -5.851。

**Dev Accuracy = 74.77%**（dev 全部 3000 筆，包含 NEI；分類器看的是實際檢索到的證據，這裡只比對標籤）。不做任何調整時是 74.53%。混淆矩陣如下（列是正確答案、欄是預測）：

| 正確答案 \ 預測 | SUPPORTS | REFUTES | NOT ENOUGH INFO |
| :---: | :---: | :---: | :---: |
| SUPPORTS | 758 | 125 | 117 |
| REFUTES | 96 | 732 | 172 |
| NOT ENOUGH INFO | 69 | 178 | 753 |

4. … Anything that can strengthen your report. (10%)

Answer:

**(1) v1 → v2 → v3 改了什麼、進步多少**：v1 的 public score 是 0.77600（排行榜第 64 名）。v2 保留 v1 的文件檢索，改進證據和分類兩段：初篩 20 → 30 句、微調 reranker、分類器 base → large、輸入 256 → 512 token 並把標準證據放前面、NEI 訓練證據改用 reranker 挑、NEI 決策加上 reranker 門檻，public score 進步到 0.85600（第 50 名）。v3 根據 v2 的三階段漏斗只改分類：3 個模型的 ensemble，並放寬 NEI bias 和門檻的搜尋範圍。三版在 dev 上的比較如下：

| 指標（dev） | v1 | v2 | v3 |
| :---: | :---: | :---: | :---: |
| Document Recall@5 | 88.85% | 88.85% | 88.85% |
| Evidence Recall@5 | 82.70% | 85.85% | 85.50% |
| Classification Accuracy | 67.83% | 73.30% | 74.77% |
| FEVER score | 62.27% | 69.00% | 70.03% |
| Kaggle public score | 0.77600 | 0.85600 | （提交後填入） |

這次重新跑了檢索，文件和證據的數字和 v2 有一點差異（reranker 的微調在 GPU 上不是完全可重現）。dev FEVER score 從 v2 的 69.00% 變成 70.03%，提升了 1.03 個百分點。

**(2) 證據被截斷的問題（v2 修正）**：我從 train 的 SUPPORTS / REFUTES 抽 2,000 題實際量過：v1 的設定（256 token、證據順序打亂、句子不限長）下，標準證據能完整留在輸入裡的比例是 66.50%；v2 的設定（512 token、標準證據在前、每句 ≤ 120 字）是 100.00%。輸入長度的中位數是 287 token，超過 256 的有 66.45%，所以 v1 確實有不少訓練資料是在「看不到證據」的情況下被要求回答 SUPPORTS / REFUTES，模型學到的其實是雜訊，這是 v2 把長度放寬、標準證據放前面的原因。

**(3) 三階段漏斗：分數到底卡在哪一步？** 我把 dev 裡 2000 筆 SUPPORTS / REFUTES 一路追下去，看每一步還剩幾題：

| 階段 | 題數 | 佔可驗證題 |
| :---: | :---: | :---: |
| SUPPORTS / REFUTES 題數 | 2000 | 100.00% |
| ① 前 5 頁找齊證據頁 | 1777 | 88.85% |
| ② 前 5 句找齊證據句 | 1710 | 85.50% |
| ③ 標籤也判斷正確（= 拿到 FEVER 分數） | 1348 | 67.40% |

損失最多的是「分類」這一步，少了 362 題（佔可驗證題 18.10%），代表證據已經找到但分類器判斷錯。v3 已經用了 ensemble，之後可以把 train + dev 合起來訓練最終模型，或換更大的分類模型。另外，NOT ENOUGH INFO 的 1000 題中有 753 題判斷正確。和 v2 比：第 ③ 步（證據找齊、標籤也對）從 1300 題變成 1348 題，NOT ENOUGH INFO 判對的題數從 770 題變成 753 題。

**(4) NEI 決策：Accuracy 和 FEVER score 的取捨**。v1 只在 NEI 的分數加 bias；v2 再加一個規則：reranker 給第 1 名句子的分數如果低於門檻，代表連最像的句子都不太像證據，直接判 NEI。v2 搜尋的 bias 範圍是 -1.5～1.5，結果選到邊界的 -1.5，所以 v3 把範圍放寬到 -3.0, -2.5, -2.0, -1.5, -1.0, -0.5, 0.0, 0.5, 1.0；門檻取 dev 上第 1 名分數的 2.5%, 5%, 7.5%, 10%, 12.5%, 15%, 20% 分位數。下面是 v3 選用的模型組合只調 NEI bias 的結果：

| NEI bias | Accuracy | FEVER score | 預測為 NEI 的比例 |
| :---: | :---: | :---: | :---: |
| -3.0 | 60.57% | 54.20% | 4.73% |
| -2.5 | 63.77% | 57.60% | 8.83% |
| -2.0 | 66.50% | 60.57% | 12.87% |
| -1.5 | 69.97% | 64.23% | 18.27% |
| -1.0 | 72.20% | 66.73% | 22.83% |
| -0.5 | 74.13% | 68.90% | 27.77% |
| 0.0 | 74.53% | 69.80% | 34.50% |
| 0.5 | 72.07% | 68.10% | 42.87% |
| 1.0 | 70.30% | 67.17% | 50.70% |

NEI bias 和 reranker 門檻一起調（每個門檻只列出該門檻下最好的 bias）：

| reranker 門檻 | 該門檻下最好的 NEI bias | Accuracy | FEVER score | 預測為 NEI 的比例 |
| :---: | :---: | :---: | :---: | :---: |
| 不使用 | 0.0 | 74.53% | 69.80% | 34.50% |
| 最低 2.5%（分數 < -6.87） | 0.0 | 74.63% | 69.90% | 34.60% |
| 最低 5%（分數 < -5.85） | 0.0 | 74.77% | 70.03% | 34.73% |
| 最低 7.5%（分數 < -3.90） | 0.0 | 74.60% | 69.97% | 34.93% |
| 最低 10%（分數 < -1.54） | 0.0 | 74.50% | 70.00% | 35.50% |
| 最低 12.5%（分數 < 0.25） | 0.0 | 74.17% | 69.80% | 36.17% |
| 最低 15%（分數 < 1.15） | 0.0 | 73.53% | 69.33% | 37.13% |
| 最低 20%（分數 < 2.16） | 0.0 | 72.40% | 68.47% | 39.17% |

最後選的是 NEI bias = 0.0，而且 reranker 第 1 名分數最低的 5% 題（分數 < -5.851）一律判 NEI。dev FEVER score 從不調整的 69.80%，只調 bias 變成 69.80%，兩個一起調變成 70.03%；Accuracy 則從 74.53% 變成 74.77%。Accuracy 和 FEVER score 看的東西不一樣：SUPPORTS / REFUTES 的題目如果證據沒找到，標籤猜對也拿不到分，把這種題改猜 NEI 幾乎沒有損失，卻能多拿到真正 NEI 題的分數。reranker 的分數正好是「證據有沒有找到」的訊號，所以比只看分類器的 NEI 機率多一個判斷依據。因為競賽是用 FEVER score 排名，test 我用這組設定。

**(5) 標題加分的消融實驗**：bonus = 0 等於只用向量排序，bonus 很大等於「標題命中的頁一定排在前面」。

| title bonus | Doc Recall@5 | 命中題數 |
| :---: | :---: | :---: |
| 0.0 | 87.50% | 1750 / 2000 |
| 0.05 | 88.85% | 1777 / 2000 |
| 0.1 | 88.80% | 1776 / 2000 |
| 0.15 | 88.50% | 1770 / 2000 |
| 0.2 | 87.90% | 1758 / 2000 |
| 0.3 | 86.55% | 1731 / 2000 |
| 0.5 | 85.45% | 1709 / 2000 |
| 1.0 | 85.45% | 1709 / 2000 |

bonus = 0.05 時 Recall@5 最高（88.85%），但 bonus 開到 1.0 時下降到 85.45%。我推測是因為國名、年份這類很通用的短標題也會被比對到，加太多分會把真正的頁擠出前 5 名，所以標題比對適合當「加分」而不是「絕對優先」。

**(6) 作業規定的檢查**：這份 notebook 一共用了 5 個預訓練模型，每一個都小於 1B：檢索用的 bge-m3（568M）、bge-reranker-v2-m3（568M），以及分類用的 chinese-roberta-wwm-ext-large（326M）、chinese-macbert-large（326M）、xlm-roberta-large（560M）。助教 11/06 答覆 1B 的限制是逐一適用於每個模型，ensemble 不合併計算。全部在 Kaggle / Colab 的 GPU 上執行，沒有呼叫任何外部推理 API。訓練資料只用 CFEVER 的 train（reranker 和 3 個分類器都是），dev 只用來挑 bonus、NEI bias、reranker 門檻、ensemble 的模型組合、選 epoch 和報告分數，test 只讀 `id` 和 `claim`，沒有用到 test 的答案。

**(7) 限制與之後想做的事**：

* bonus、NEI bias、門檻、epoch 和 ensemble 的模型組合都是在同一份 dev 上挑的，所以 dev 分數會比真實情況稍微樂觀一點。比較嚴謹的做法是把 dev 切成兩半，一半挑參數、另一半報告分數。
* 文件檢索還有 11.15% 的 SUPPORTS / REFUTES 沒有找齊證據頁，常見的是 claim 用的是別名或比較口語的說法（例如 claim 寫「爬蟲類」，頁名是「爬行動物」），v3 沒有處理這部分，之後可以讓頁面也用 cross-encoder 重排。
* reranker 是一句一句分開打分數，需要 2 句以上一起才能判斷的題目，第 2 句單獨看常常不像證據，容易被排到後面。之後可以讓 reranker 一次看多句。
* 參數挑好之後，可以把 train 和 dev 合起來重新訓練最終的分類器，資料多 12%，但就沒有 dev 可以檢查了。

5. Generative AI Usage Statement

Answer:

我有使用生成式 AI，使用情況如下：

* **使用工具**：主要是 Claude（Anthropic，透過 Claude Code）；另外也把題目丟給 ChatGPT 和 Gemini 問過提升分數的方向，再由我比較後決定最後的做法。
* **使用範圍**：(1) 理解 CFEVER 三階段流程和 FEVER score 的計算方式；(2) 協助把 sample code 改寫成「標題比對 + bge-m3 + reranker + RoBERTa」的 v1；v1 拿到 public score 0.776 之後，討論並實作 v2 的改進（微調 reranker、換成 large 分類器、處理證據截斷、NEI 決策規則）；v2 拿到 0.856 之後，依照 v2 的三階段漏斗決定 v3 只改分類，並實作 3 個分類器的 ensemble；還有自動把數字填進報告的程式；(3) 整理學習筆記、練習題和我可能會問的問題；(4) 報告初稿的文字整理。
* **主要 prompt**：「依照作業規範改寫 sample code 並回答 report」、「評估 Claude 和 Gemini 提出的提分建議，哪個在 GPU 時數內比較可行」、「v1 只有 0.776、排第 64 名，還有什麼方法可以提升，幫我寫 v2，一樣要遵守作業規範」、「目前 v2 是 0.85，要不要試試看 v3」、「整理我讀這份程式可能會問的問題」。
* 報告裡的數字都是我這次在 Kaggle / Colab 實際執行後印出來的結果，不是 AI 生成的；程式最上方的註解也有標註生成式 AI 的使用和參考連結。