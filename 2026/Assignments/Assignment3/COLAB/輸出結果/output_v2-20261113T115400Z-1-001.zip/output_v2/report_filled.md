# Report

Your Kaggle username: zhi816

Your public leaderboard score: （提交 Kaggle 後填入）

Your private leaderboard score: （11/23 公布後填入）


1. Describe your method for retrieving Wikipedia documents (5%) and report Recall@N on development set (5%).

Answer:

我讀 sample code 時發現，它只把 train 有標註過的頁面當候選，dev / test 的正確頁面如果沒在 train 出現過，就一定找不到。所以我改成讀完整的 `wiki_pages.jsonl`（共 1,187,751 頁），並把文件檢索拆成「先找候選、再排順序」兩步（這一段和我第一版 v1 的做法相同，v2 主要改的是後面兩個階段）：

* **(1) 標題比對（找候選）**：維基的頁名常常就是 claim 裡的主角，例如 claim 在講某部電影，頁名通常就是那部電影的名字。我先把所有頁名正規化（去掉結尾的消歧義括號、統一「·」這類間隔號、去掉空白、英文轉小寫），做成「標題 → 頁面」的 dict，再把 claim 中所有長度 2～30 的子字串拿去查。查到的就是候選頁，長的標題比較具體所以排前面，每題最多留 30 頁。這一步只是 Python 的 dict 查詢，不用 GPU、也不用斷詞。dev 平均每題命中 17.5 頁，完全沒有命中任何標題的有 0 題（0.00%）。
* **(2) 向量排序**：候選頁用 `BAAI/bge-m3`（568M 參數）把「頁名：開頭 200 字」編成向量，claim 也編成向量，兩邊都做 L2 normalization，所以內積就是 cosine similarity。bge-m3 是專門為檢索訓練過的模型，訓練時用的是 [CLS] 位置的向量，所以我照它的設計取 [CLS]，而不是 sample code 的 mean pooling。為了照顧「claim 裡沒有直接寫出頁名」的題目，我另外在候選池（train 標註頁 3,188 頁 + 所有 claim 的標題命中頁，合計 41,081 頁）裡用向量再補 30 頁。
* **(3) 混合分數**：最終分數 = cosine + bonus × [這頁是否被標題命中]。bonus 我在 dev 上從 0.0, 0.05, 0.1, 0.15, 0.2, 0.3, 0.5, 1.0 裡挑 Recall@5 最高的，結果是 **0.05**，取前 5 頁進入下一階段。

**Dev 結果**：dev 共 3000 筆，Recall 只計算 SUPPORTS / REFUTES 的 2000 筆；某一組標準證據需要的頁面「全部」都在前 N 頁裡才算命中。

**Document Retrieval Recall@5 = 88.85%（1777 / 2000）**

| 方法 | R@1 | R@3 | R@5 | R@10 |
| :---: | :---: | :---: | :---: | :---: |
| 只用標題比對（長標題優先） | 42.85% | 66.70% | 76.15% | 83.00% |
| 只用 bge-m3 向量（bonus = 0） | 74.80% | 85.00% | 87.50% | 89.60% |
| 混合（bonus = 0.05） | 77.05% | 86.40% | 88.85% | 90.60% |

只用標題比對的 Recall@5 是 76.15%，只用向量是 87.50%，兩種合起來是 88.85%，比單用較好的那一種提升了 1.35 個百分點。另外，「標題命中 + 向量補充」的候選頁涵蓋率是 91.80%，這是排序再怎麼改都超不過的上限。

2. Describe your method for retrieving evidence (5%) and report Recall@N on development set  (5%).

Answer:

證據只能從第 1 階段取回的 5 頁裡挑。sample code 只把 train 標註過的句子當候選，我改成把這幾頁的**每一句**都當候選（保留維基原始的句號，不重新編號），全部共編碼了 134,939 句。每一句前面我都加上頁名（「頁名：句子」），因為很多句子是用「他」「該片」來代稱主角，不加頁名的話模型不知道這句在講誰。

* **(1) 向量初篩**：用同一個 bge-m3 算 claim 和每一句的 cosine similarity，每題先留前 30 句。v1 只留 20 句，但我發現 reranker 再厲害也只能從初篩留下的句子裡挑，所以 v2 放寬到 30 句，提高上限。
* **(2) Cross-encoder 重排**：再用 `BAAI/bge-reranker-v2-m3`（568M 參數）把「claim + 句子」一起丟進模型打分數。向量檢索是 bi-encoder，claim 和句子各自算向量再比，速度快但兩邊沒有真正一起讀；cross-encoder 讓 claim 和句子的每個字互相做 attention，比較能分辨同一頁裡內容很接近的句子。
* **(3) 用 CFEVER train 微調 reranker（v2 新增）**：現成的 reranker 只學過一般的「這句和問題相不相關」，但 CFEVER 要的是「能用來判斷真假的那一句」，而且標註者挑句子有自己的習慣。所以我用 train 的 8,000 題 SUPPORTS / REFUTES 微調它：每題組成 1 個正例（標準證據句）+ 7 個 hard negative（bge-m3 初篩排很前面、但不是標準證據的句子），reranker 對 8 句各打一個分數，再把 8 個分數當成「8 選 1」做 cross entropy，目標是讓標準證據的分數比其他 7 句都高（listwise loss，參考 FlagEmbedding 訓練 bge-reranker 的方式）。為了讓 T4 放得下，我凍結了詞向量層（約 2.5 億參數），只訓練後面的 transformer 層；learning rate 2e-05、1 個 epoch、fp16 混合精度，大約花 15 分鐘。dev 完全沒有拿來訓練，微調完會和現成的模型在 dev 上比較，比較好才採用，最後用的是**微調後的** reranker。
* **(4) 固定給滿 5 句**：FEVER score 只看前 5 句，多給不會扣分，所以每題都輸出 5 句，盡量提高命中機會。

**Dev 結果**：同樣只算 2000 筆可驗證的題目，頁名和句號都要對，而且要完整涵蓋某一組標準證據才算命中。

**Evidence Retrieval Recall@5 = 85.85%（1717 / 2000）**

| 方法 | Evidence Recall@5 |
| :---: | :---: |
| bge-m3 向量取前 5 句 | 81.40% |
| bge-m3 向量前 20 句（v1 reranker 能到的上限） | 88.30% |
| bge-m3 向量前 30 句（v2 reranker 能到的上限） | 88.80% |
| ＋ 現成 bge-reranker 從 30 句重排取前 5 | 82.45% |
| ＋ 微調後 bge-reranker 從 30 句重排取前 5 | 85.85% |

只用向量挑 5 句的 Recall 是 81.40%；現成的 reranker 從 30 句重排後是 82.45%；用 train 微調 reranker 之後是 85.85%，比現成的提升了 3.40 個百分點，所以最後採用微調後的 reranker。向量前 30 句的 Recall 是 88.80%（前 20 句是 88.30%），這是 reranker 再厲害也超不過的上限，這也是我把初篩從 v1 的 20 句放寬到 30 句的原因。如果只看「文件已經找對」的題目，證據 Recall@5 是 96.62%：只要頁面找對，大部分題目都能把證據句找齊，證據 Recall 的損失主要來自第 1 階段沒有找到正確頁面。

3. Describe your classification method (5%) and report Accuracy on development set  (5%).

Answer:

分類模型我用 `hfl/chinese-roberta-wwm-ext-large`（326M 參數），在上面接一個三分類層（SUPPORTS / REFUTES / NOT ENOUGH INFO）。v1 用的是同系列的 base 版（102M），v2 換成 large 版：層數從 12 層變成 24 層、hidden size 從 768 變成 1024，推論能力比較強，參數量仍然遠小於 1B。輸入是句對 `[CLS] claim [SEP] 【頁名】證據句1 【頁名】證據句2 … [SEP]`，太長時只截斷證據、不截斷 claim。

v2 我特別處理了「證據被截掉」的問題：

* **輸入長度從 256 放寬到 512 token，每句證據最多 120 字**。5 句證據加上頁名常常超過 256 token，超過的部分會直接被丟掉；限制單句長度則是避免一句特別長的句子把其他句子擠出去。
* **訓練時標準證據放在最前面**（v1 是打亂順序）。測試時 reranker 也會把最像證據的句子排第 1，所以訓練和測試的輸入長得一樣；而且就算還是超過長度，被截掉的也是排在後面、比較不重要的句子。實際量到的截斷比例寫在第 4 題 (2)。

訓練資料的其他部分和 v1 一樣：

* **SUPPORTS / REFUTES**：先拿檢索到的 5 句；如果標準證據不在裡面，就放進一組標準證據、擠掉排名最後的句子。因為 FEVER score 規定 SUPPORTS / REFUTES 的證據沒找到就是 0 分，分類器真正要做好的是「證據對的時候判斷正確」，所以要確保模型訓練時一定看得到真正能判斷的證據。
* **NOT ENOUGH INFO**：這類題目沒有標準證據。v2 改成用 reranker 從向量前 10 句挑出 5 句當證據，讓它和 test 時一樣「看起來很相關、但其實資訊不夠」，模型才學得會什麼時候該選 NEI。

訓練用了 24,012 筆 train（其中 2,749 筆有補進標準證據；0 筆在維基裡找不到標準證據句，所以沒拿來訓練）。設定是 AdamW、learning rate 1e-05（large 模型用比較小的學習率比較穩）、每批 8 筆並用 gradient accumulation 累積 2 批才更新一次（等效 batch size 16）、2 個 epoch、前 10% 的更新步數做 warmup 之後線性下降、gradient clipping 1.0，並用 fp16 混合精度加速。每個 epoch 結束我都在 dev 上看一次，最後採用 dev FEVER score 最高的第 2 個 epoch：

| epoch | train loss | dev Accuracy | dev FEVER score |
| :---: | :---: | :---: | :---: |
| 1 | 0.7358 | 70.37% | 66.77% |
| 2 | 0.3918 | 71.47% | 67.80% |

預測時我另外用了 NEI bias 和 reranker 門檻（第 4 題說明），最後選 NEI bias = -1.5、門檻 = -1.548。

**Dev Accuracy = 73.30%**（dev 全部 3000 筆，包含 NEI；分類器看的是實際檢索到的證據，這裡只比對標籤）。不做任何調整時是 71.47%。混淆矩陣如下（列是正確答案、欄是預測）：

| 正確答案 \ 預測 | SUPPORTS | REFUTES | NOT ENOUGH INFO |
| :---: | :---: | :---: | :---: |
| SUPPORTS | 745 | 114 | 141 |
| REFUTES | 117 | 684 | 199 |
| NOT ENOUGH INFO | 91 | 139 | 770 |

4. … Anything that can strengthen your report. (10%)

Answer:

**(1) v1 → v2 改了什麼、進步多少**：我第一版（v1）交出去的 public score 是 0.77600，當時在排行榜上排第 64 名。v2 保留 v1 的文件檢索，針對證據和分類兩段改進，一共改了 6 個地方：初篩 20 → 30 句、微調 reranker、分類器 base → large、輸入 256 → 512 token 並把標準證據放前面、NEI 訓練證據改用 reranker 挑、NEI 決策加上 reranker 門檻。兩版在 dev 上的比較如下：

| 指標（dev） | v1 | v2 |
| :---: | :---: | :---: |
| Document Recall@5 | 88.85% | 88.85% |
| Evidence Recall@5 | 82.70% | 85.85% |
| Classification Accuracy | 67.83% | 73.30% |
| FEVER score | 62.27% | 69.00% |
| Kaggle public score | 0.77600 | （提交後填入） |

v1 的 dev 數字是從 v1 notebook 輸出的 `metrics.json` 讀進來的，兩版用的是同一份 dev（3,000 筆）。

**(2) 證據被截斷的問題**：我從 train 的 SUPPORTS / REFUTES 抽 2,000 題實際量過：v1 的設定（256 token、證據順序打亂、句子不限長）下，標準證據能完整留在輸入裡的比例是 66.50%；v2 的設定（512 token、標準證據在前、每句 ≤ 120 字）是 100.00%。v2 輸入長度的中位數是 287 token，超過 256 的有 66.45%，所以 v1 確實有不少訓練資料是在「看不到證據」的情況下被要求回答 SUPPORTS / REFUTES，模型學到的其實是雜訊，這是 v2 把長度放寬、標準證據放前面的原因。

**(3) 三階段漏斗：分數到底卡在哪一步？** 我把 dev 裡 2000 筆 SUPPORTS / REFUTES 一路追下去，看每一步還剩幾題：

| 階段 | 題數 | 佔可驗證題 |
| :---: | :---: | :---: |
| SUPPORTS / REFUTES 題數 | 2000 | 100.00% |
| ① 前 5 頁找齊證據頁 | 1777 | 88.85% |
| ② 前 5 句找齊證據句 | 1717 | 85.85% |
| ③ 標籤也判斷正確（= 拿到 FEVER 分數） | 1300 | 65.00% |

損失最多的是「分類」這一步，少了 417 題（佔可驗證題 20.85%），代表證據已經找到但分類器判斷錯，之後可以做多個模型的 ensemble，或把 train + dev 合起來訓練最終模型。另外，NOT ENOUGH INFO 的 1000 題中有 770 題判斷正確。

**(4) NEI 決策：Accuracy 和 FEVER score 的取捨**。v1 只在 NEI 的 logit 加 bias；v2 再加一個規則：reranker 給第 1 名句子的分數如果低於門檻（取 dev 上第 1 名分數的 5%, 10%, 15%, 20%, 25%, 30% 分位數），代表連最像的句子都不太像證據，直接判 NEI。只調 NEI bias 的結果：

| NEI bias | Accuracy | FEVER score | 預測為 NEI 的比例 |
| :---: | :---: | :---: | :---: |
| -1.5 | 73.30% | 68.73% | 36.17% |
| -1.0 | 72.87% | 68.63% | 39.93% |
| -0.5 | 72.30% | 68.23% | 42.60% |
| 0.0 | 71.47% | 67.80% | 45.77% |
| 0.5 | 70.63% | 67.37% | 49.90% |
| 1.0 | 68.67% | 65.77% | 53.40% |
| 1.5 | 66.87% | 64.30% | 56.93% |

NEI bias 和 reranker 門檻一起調（每個門檻只列出該門檻下最好的 bias）：

| reranker 門檻 | 該門檻下最好的 NEI bias | Accuracy | FEVER score | 預測為 NEI 的比例 |
| :---: | :---: | :---: | :---: | :---: |
| 不使用 | -1.5 | 73.30% | 68.73% | 36.17% |
| 最低 5%（分數 < -5.18） | -1.5 | 73.33% | 68.87% | 36.40% |
| 最低 10%（分數 < -1.55） | -1.5 | 73.30% | 69.00% | 37.00% |
| 最低 15%（分數 < 1.17） | -1.5 | 72.93% | 68.97% | 38.67% |
| 最低 20%（分數 < 2.18） | -1.5 | 71.77% | 68.23% | 41.10% |
| 最低 25%（分數 < 2.91） | -1.5 | 70.20% | 66.73% | 43.83% |
| 最低 30%（分數 < 3.45） | -1.5 | 68.30% | 64.97% | 46.50% |

最後選的是 NEI bias = -1.5，而且 reranker 第 1 名分數最低的 10% 題（分數 < -1.548）一律判 NEI。dev FEVER score 從不調整的 67.80%，只調 bias 變成 68.73%，兩個一起調變成 69.00%；Accuracy 則從 71.47% 變成 73.30%。Accuracy 和 FEVER score 看的東西不一樣：SUPPORTS / REFUTES 的題目如果證據沒找到，標籤猜對也拿不到分，把這種題改猜 NEI 幾乎沒有損失，卻能多拿到真正 NEI 題的分數。reranker 的分數正好是「證據有沒有找到」的訊號，所以比只看分類器的 NEI 機率多一個判斷依據。因為競賽是用 FEVER score 排名，test 我用這組設定。

**(5) 標題加分的消融實驗**：bonus = 0 等於只用向量排序，bonus 很大等於「標題命中的頁一定排在前面」。

| title bonus | Doc Recall@5 | 命中題數 |
| :---: | :---: | :---: |
| 0.0 | 87.50% | 1750 / 2000 |
| 0.05 | 88.85% | 1777 / 2000 |
| 0.1 | 88.80% | 1776 / 2000 |
| 0.15 | 88.50% | 1770 / 2000 |
| 0.2 | 87.90% | 1758 / 2000 |
| 0.3 | 86.55% | 1731 / 2000 |
| 0.5 | 85.45% | 1709 / 2000 |
| 1.0 | 85.45% | 1709 / 2000 |

bonus = 0.05 時 Recall@5 最高（88.85%），但 bonus 開到 1.0 時下降到 85.45%。我推測是因為國名、年份這類很通用的短標題也會被比對到，加太多分會把真正的頁擠出前 5 名，所以標題比對適合當「加分」而不是「絕對優先」。

**(6) 作業規定的檢查**：三個模型 bge-m3（568M）、bge-reranker-v2-m3（568M）、chinese-roberta-wwm-ext-large（326M）每一個都小於 1B；全部在 Kaggle / Colab 的 GPU 上執行，沒有呼叫任何外部推理 API。訓練資料只用 CFEVER 的 train（reranker 和分類器都是），dev 只用來挑 bonus、NEI bias、reranker 門檻、選 epoch 和報告分數，test 只讀 `id` 和 `claim`，沒有用到 test 的答案。

**(7) 限制與之後想做的事**：

* bonus、NEI bias、門檻和 epoch 都是在同一份 dev 上挑的，所以 dev 分數會比真實情況稍微樂觀一點。比較嚴謹的做法是把 dev 切成兩半，一半挑參數、另一半報告分數。
* reranker 是一句一句分開打分數，需要 2 句以上一起才能判斷的題目，第 2 句單獨看常常不像證據，容易被排到後面。之後可以讓 reranker 一次看多句。
* 參數挑好之後，可以把 train 和 dev 合起來重新訓練最終的分類器，或是訓練幾個不同 seed 的模型做 ensemble，應該還能再提升，但 GPU 時數會再多一倍以上。

5. Generative AI Usage Statement

Answer:

我有使用生成式 AI，使用情況如下：

* **使用工具**：主要是 Claude（Anthropic，透過 Claude Code）；另外也把題目丟給 ChatGPT 和 Gemini 問過提升分數的方向，再由我比較後決定最後的做法。
* **使用範圍**：(1) 理解 CFEVER 三階段流程和 FEVER score 的計算方式；(2) 協助把 sample code 改寫成「標題比對 + bge-m3 + reranker + RoBERTa」的 v1，以及 v1 拿到 public score 0.776 之後，討論並實作 v2 的改進（微調 reranker、換成 large 分類器、處理證據截斷、NEI 決策規則），還有自動把數字填進報告的程式；(3) 整理學習筆記、練習題和我可能會問的問題；(4) 報告初稿的文字整理。
* **主要 prompt**：「依照作業規範改寫 sample code 並回答 report」、「評估 Claude 和 Gemini 提出的提分建議，哪個在 GPU 時數內比較可行」、「v1 只有 0.776、排第 64 名，還有什麼方法可以提升，幫我寫 v2，一樣要遵守作業規範」、「整理我讀這份程式可能會問的問題」。
* 報告裡的數字都是我這次在 Kaggle / Colab 實際執行後印出來的結果，不是 AI 生成的；程式最上方的註解也有標註生成式 AI 的使用和參考連結。